<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "link.php"; ?>
</head>


<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidebar.php"; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topbar.php"; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">List Data Gangguan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataX" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ID Pelanggan</th>
                                            <th>Nama</th>
                                            <th>CRT</th>
                                            <th>Type Perangkat</th>
                                            <th>SN / MAC</th>
                                            <th>MAC</th>
                                            <th>User PPOE</th>
                                            <th>Pass PPOE</th>
                                            <th>SSID WIFI</th>
                                            <th>Password WIFI</th>
                                            <th>Password Device</th>
                                            <th>Konfigurasi By</th>
                                            <th>Instalasi By</th>
                                            <th>Location On Google Map</th>
                                            <th>Keterangan</th>
                                            <th>IP</th>
                                            <th>Keterangan IP</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $stmt = $conn->prepare("SELECT * FROM data_gangguan");
                                        $stmt->execute();
                                        $data_gangguan = $stmt->get_result();
                                        $i = 1;
                                        foreach ($data_gangguan as $data) :
                                        ?>
                                            <tr>
                                                <td><?= $i; ?></td>
                                                <td><?= htmlspecialchars($data['id_pelanggan']); ?></td>
                                                <td><?= htmlspecialchars($data['nama']); ?></td>
                                                <td><?= htmlspecialchars($data['crt']); ?></td>
                                                <td><?= htmlspecialchars($data['type_perangkat']); ?></td>
                                                <td><?= htmlspecialchars($data['sn_mac']); ?></td>
                                                <td><?= htmlspecialchars($data['mac']); ?></td>
                                                <td><?= htmlspecialchars($data['user_ppoe']); ?></td>
                                                <td><?= htmlspecialchars($data['pass_ppoe']); ?></td>
                                                <td><?= htmlspecialchars($data['ssid_wifi']); ?></td>
                                                <td><?= htmlspecialchars($data['password_wifi']); ?></td>
                                                <td><?= htmlspecialchars($data['password_device']); ?></td>
                                                <td><?= htmlspecialchars($data['konfigurasi_by']); ?></td>
                                                <td><?= htmlspecialchars($data['instalasi_by']); ?></td>
                                                <td><?= htmlspecialchars($data['location_on_google_map']); ?></td>
                                                <td><?= htmlspecialchars($data['keterangan']); ?></td>
                                                <td><?= htmlspecialchars($data['ip']); ?></td>
                                                <td><?= htmlspecialchars($data['keterangan_ip']); ?></td>
                                                <td>
                                                    <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#hapusModal<?= $data['id_pelanggan']; ?>">Hapus</a>
                                                </td>
                                            </tr>

                                            <!-- Modal Hapus -->
                                            <div class="modal fade" id="hapusModal<?= $data['id_pelanggan']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Hapus Data Gangguan</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Apakah Anda yakin ingin menghapus data dengan ID Pelanggan: <b><?= htmlspecialchars($data['id_pelanggan']); ?></b>?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                                                            <form action="" method="post">
                                                                <input type="hidden" name="id_pelanggan" value="<?= $data['id_pelanggan']; ?>">
                                                                <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php
                                            $i++;
                                        endforeach;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Content Row -->
                <!-- DataTales Example -->


            </div>

        </div>


    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <?php include "footer.php"; ?>
    <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php include "plugin.php"; ?>

    <script>
        $(document).ready(function() {
            $('#dataX').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json",
                    "oPaginate": {
                        "sFirst": "Pertama",
                        "sLast": "Terakhir",
                        "sNext": "Selanjutnya",
                        "sPrevious": "Sebelumnya"
                    },
                    "sInfo": "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
                    "sSearch": "Cari:",
                    "sEmptyTable": "Tidak ada data yang tersedia dalam tabel",
                    "sLengthMenu": "Tampilkan _MENU_ data",
                    "sZeroRecords": "Tidak ada data yang cocok dengan pencarian Anda"
                }
            });
        });
    </script>

    <script>
        <?php if (isset($script)) {
            echo $script;
        } ?>
    </script>
</body>

</html>