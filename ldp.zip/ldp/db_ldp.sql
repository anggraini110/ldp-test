-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 03:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ldp`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_gangguan`
--

CREATE TABLE `data_gangguan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `crt` varchar(255) DEFAULT NULL,
  `type_perangkat` varchar(255) DEFAULT NULL,
  `sn_mac` varchar(255) DEFAULT NULL,
  `mac` varchar(255) DEFAULT NULL,
  `user_ppoe` varchar(255) DEFAULT NULL,
  `pass_ppoe` varchar(255) DEFAULT NULL,
  `ssid_wifi` varchar(255) DEFAULT NULL,
  `password_wifi` varchar(255) DEFAULT NULL,
  `password_device` varchar(255) DEFAULT NULL,
  `konfigurasi_by` varchar(255) DEFAULT NULL,
  `instalasi_by` varchar(255) DEFAULT NULL,
  `location_on_google_map` varchar(255) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `keterangan_ip` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `tipe_akun` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `tipe_akun`) VALUES
(1, 'adee', '$2y$10$krlyRkUdDpUwthvmJpH8cOmckcW5GTM4DS4vtZwWAVyer33MXRtha', 'Client'),
(2, 'anggraini', '$2y$10$UDLJXNzNGZ2Aub216imEteEPqeNi9cHUBzt/LHtJnxavgxpBGlYJu', 'Customer Service');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_gangguan`
--
ALTER TABLE `data_gangguan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_gangguan`
--
ALTER TABLE `data_gangguan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
