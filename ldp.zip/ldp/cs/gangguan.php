<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "link.php"; ?>
</head>

<?php

if (isset($_POST['submit'])) {
    // Ambil data dari form
    $id_pelanggan = mysqli_real_escape_string($conn, $_POST['id_pelanggan']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $crt = mysqli_real_escape_string($conn, $_POST['crt']);
    $type_perangkat = mysqli_real_escape_string($conn, $_POST['type_perangkat']);
    $sn_mac = mysqli_real_escape_string($conn, $_POST['sn_mac']);
    $mac = mysqli_real_escape_string($conn, $_POST['mac']);
    $user_ppoe = mysqli_real_escape_string($conn, $_POST['user_ppoe']);
    $pass_ppoe = mysqli_real_escape_string($conn, $_POST['pass_ppoe']);
    $ssid_wifi = mysqli_real_escape_string($conn, $_POST['ssid_wifi']);
    $password_wifi = mysqli_real_escape_string($conn, $_POST['password_wifi']);
    $password_device = mysqli_real_escape_string($conn, $_POST['password_device']);
    $konfigurasi_by = mysqli_real_escape_string($conn, $_POST['konfigurasi_by']);
    $instalasi_by = mysqli_real_escape_string($conn, $_POST['instalasi_by']);
    $location_on_google_map = mysqli_real_escape_string($conn, $_POST['location_on_google_map']);
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    $ip = mysqli_real_escape_string($conn, $_POST['ip']);
    $keterangan_ip = mysqli_real_escape_string($conn, $_POST['keterangan_ip']);

    // Simpan data ke database
    $query = "INSERT INTO data_gangguan (id_pelanggan, nama, crt, type_perangkat, sn_mac, mac, user_ppoe, pass_ppoe, ssid_wifi, password_wifi, password_device, konfigurasi_by, instalasi_by, location_on_google_map, keterangan, ip, keterangan_ip) VALUES ('$id_pelanggan', '$nama', '$crt', '$type_perangkat', '$sn_mac', '$mac', '$user_ppoe', '$pass_ppoe', '$ssid_wifi', '$password_wifi', '$password_device', '$konfigurasi_by', '$instalasi_by', '$location_on_google_map', '$keterangan', '$ip', '$keterangan_ip')";

    if (mysqli_query($conn, $query)) {
        $script = "
            Swal.fire({
                icon: 'success',
                title: 'Data Berhasil Ditambahkan!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Data Gagal Ditambahkan!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    }
}

if (isset($_POST['hapus'])) {
    // Ambil data dari form
    $id_pelanggan = mysqli_real_escape_string($conn, $_POST['id_pelanggan']);

    $query = "DELETE FROM data_gangguan WHERE id_pelanggan = '$id_pelanggan'";
    if (mysqli_query($conn, $query)) {
        $script = "
            Swal.fire({
                icon: 'success',
                title: 'Data Berhasil Dihapus!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    } else {
        $script = "
            Swal.fire({
                icon: 'error',
                title: 'Data Gagal Di-Hapus!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        ";
    }
}


?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include "sidebar.php"; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include "topbar.php"; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="">
                        <p>
                            <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                <i class="fas fa-plus-square"></i> Tambah Data Gangguan
                            </a>
                        </p>
                        <div class="collapse" id="collapseExample">
                            <div class="card card-body">
                                <form method="POST" action="" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="id_pelanggan">ID Pelanggan:</label>
                                        <input type="text" class="form-control" id="id_pelanggan" name="id_pelanggan" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="nama">Nama:</label>
                                        <input type="text" class="form-control" id="nama" name="nama" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="crt">CRT:</label>
                                        <input type="text" class="form-control" id="crt" name="crt" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="type_perangkat">Type Perangkat:</label>
                                        <input type="text" class="form-control" id="type_perangkat" name="type_perangkat" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="sn_mac">SN / MAC:</label>
                                        <input type="text" class="form-control" id="sn_mac" name="sn_mac" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="mac">MAC:</label>
                                        <input type="text" class="form-control" id="mac" name="mac" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="user_ppoe">User PPOE:</label>
                                        <input type="text" class="form-control" id="user_ppoe" name="user_ppoe" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="pass_ppoe">Pass PPOE:</label>
                                        <input type="password" class="form-control" id="pass_ppoe" name="pass_ppoe" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="ssid_wifi">SSID WIFI:</label>
                                        <input type="text" class="form-control" id="ssid_wifi" name="ssid_wifi" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="password_wifi">Password WIFI:</label>
                                        <input type="password" class="form-control" id="password_wifi" name="password_wifi" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="password_device">Password Device:</label>
                                        <input type="password" class="form-control" id="password_device" name="password_device" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="konfigurasi_by">Konfigurasi By:</label>
                                        <input type="text" class="form-control" id="konfigurasi_by" name="konfigurasi_by" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="instalasi_by">Instalasi By:</label>
                                        <input type="text" class="form-control" id="instalasi_by" name="instalasi_by" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="location_on_google_map">Location On Google Map:</label>
                                        <input type="text" class="form-control" id="location_on_google_map" name="location_on_google_map" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="keterangan">Keterangan:</label>
                                        <textarea class="form-control" id="keterangan" name="keterangan" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="ip">IP:</label>
                                        <input type="text" class="form-control" id="ip" name="ip" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="keterangan_ip">Keterangan IP:</label>
                                        <textarea class="form-control" id="keterangan_ip" name="keterangan_ip" required></textarea>
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-primary w-100">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Gangguan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataX" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ID Pelanggan</th>
                                            <th>Nama</th>
                                            <th>CRT</th>
                                            <th>Type Perangkat</th>
                                            <th>SN / MAC</th>
                                            <th>MAC</th>
                                            <th>User PPOE</th>
                                            <th>Pass PPOE</th>
                                            <th>SSID WIFI</th>
                                            <th>Password WIFI</th>
                                            <th>Password Device</th>
                                            <th>Konfigurasi By</th>
                                            <th>Instalasi By</th>
                                            <th>Location On Google Map</th>
                                            <th>Keterangan</th>
                                            <th>IP</th>
                                            <th>Keterangan IP</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $stmt = $conn->prepare("SELECT * FROM data_gangguan");
                                        $stmt->execute();
                                        $data_gangguan = $stmt->get_result();
                                        $i = 1;
                                        foreach ($data_gangguan as $data) :
                                        ?>
                                            <tr>
                                                <td><?= $i; ?></td>
                                                <td><?= htmlspecialchars($data['id_pelanggan']); ?></td>
                                                <td><?= htmlspecialchars($data['nama']); ?></td>
                                                <td><?= htmlspecialchars($data['crt']); ?></td>
                                                <td><?= htmlspecialchars($data['type_perangkat']); ?></td>
                                                <td><?= htmlspecialchars($data['sn_mac']); ?></td>
                                                <td><?= htmlspecialchars($data['mac']); ?></td>
                                                <td><?= htmlspecialchars($data['user_ppoe']); ?></td>
                                                <td><?= htmlspecialchars($data['pass_ppoe']); ?></td>
                                                <td><?= htmlspecialchars($data['ssid_wifi']); ?></td>
                                                <td><?= htmlspecialchars($data['password_wifi']); ?></td>
                                                <td><?= htmlspecialchars($data['password_device']); ?></td>
                                                <td><?= htmlspecialchars($data['konfigurasi_by']); ?></td>
                                                <td><?= htmlspecialchars($data['instalasi_by']); ?></td>
                                                <td><?= htmlspecialchars($data['location_on_google_map']); ?></td>
                                                <td><?= htmlspecialchars($data['keterangan']); ?></td>
                                                <td><?= htmlspecialchars($data['ip']); ?></td>
                                                <td><?= htmlspecialchars($data['keterangan_ip']); ?></td>
                                                <td>
                                                    <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#hapusModal<?= $data['id_pelanggan']; ?>">Hapus</a>
                                                </td>
                                            </tr>

                                            <!-- Modal Hapus -->
                                            <div class="modal fade" id="hapusModal<?= $data['id_pelanggan']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Hapus Data Gangguan</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Apakah Anda yakin ingin menghapus data dengan ID Pelanggan: <b><?= htmlspecialchars($data['id_pelanggan']); ?></b>?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                                                            <form action="" method="post">
                                                                <input type="hidden" name="id_pelanggan" value="<?= $data['id_pelanggan']; ?>">
                                                                <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php
                                            $i++;
                                        endforeach;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Content Row -->
                <!-- DataTales Example -->


            </div>

        </div>


    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <?php include "footer.php"; ?>
    <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php include "plugin.php"; ?>

    <script>
        $(document).ready(function() {
            $('#dataX').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json",
                    "oPaginate": {
                        "sFirst": "Pertama",
                        "sLast": "Terakhir",
                        "sNext": "Selanjutnya",
                        "sPrevious": "Sebelumnya"
                    },
                    "sInfo": "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
                    "sSearch": "Cari:",
                    "sEmptyTable": "Tidak ada data yang tersedia dalam tabel",
                    "sLengthMenu": "Tampilkan _MENU_ data",
                    "sZeroRecords": "Tidak ada data yang cocok dengan pencarian Anda"
                }
            });
        });
    </script>

    <script>
        <?php if (isset($script)) {
            echo $script;
        } ?>
    </script>
</body>

</html>